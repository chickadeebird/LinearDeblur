#feature-id LinearDeblur : ChickadeeScripts > LinearDeblur
#feature-info This script implements different deblurring algorithms



#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/StarDetector.jsh>

#define VERSION "v1.0.5beta"

#define PSF_starIndex   0
#define PSF_function    1
#define PSF_circular    2
#define PSF_status      3
#define PSF_B           4
#define PSF_A           5
#define PSF_cx          6
#define PSF_cy          7
#define PSF_sx          8
#define PSF_sy          9
#define PSF_theta      10
#define PSF_beta       11
#define PSF_residual   12
#define PSF_mad   	  12
#define PSF_x0         13
#define PSF_y0         14
#define PSF_x1         15
#define PSF_y1         16

// Determine platform and appropriate command/shell setup
let CMD_EXEC, SCRIPT_EXT;
if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
   CMD_EXEC = "cmd.exe";
   SCRIPT_EXT = ".bat";
} else {
   console.criticalln("Unsupported platform: " + CoreApplication.platform);
}


// Define platform-agnostic folder paths
let pathSeparator = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") ? "\\" : "/";
let scriptTempDir = File.systemTempDirectory + pathSeparator + "deblurConfig";
let deblurringConfigFile = scriptTempDir + pathSeparator + "deblurring_config.csv";

// Ensure the temp directory exists
if (!File.directoryExists(scriptTempDir)) {
   File.createDirectory(scriptTempDir);
}

// Define global parameters
var deblurringParameters = {
    targetView: undefined,
    targetWindow: undefined,
    strideSize: 1024,
    maxDistortion: 0.1,
    sensitivity: 5,
    structureLayers: 5,
    xyStretch: 1.5,
    deblurPythonToolsParentFolderPath: "",
    useGPU: true,
    linearImage: true,
    erosionAmount: 4,

    save: function () {
        Parameters.set("useGPU", this.useGPU);
        Parameters.set("strideSize", this.strideSize);
        Parameters.set("maxDistortion", this.maxDistortion);
        Parameters.set("sensitivity", this.sensitivity);
        Parameters.set("structureLayers", this.structureLayers);
        Parameters.set("xyStretch", this.xyStretch);
        Parameters.set("deblurPythonToolsParentFolderPath", this.deblurPythonToolsParentFolderPath);
        this.savePathToFile();
    },

    load: function () {
        if (Parameters.has("useGPU"))
            this.useGPU = Parameters.getBoolean("useGPU");
        if (Parameters.has("strideSize"))
            this.strideSize = Number(Parameters.getString("strideSize"));
        if (Parameters.has("maxDistortion"))
            this.maxDistortion = Number(Parameters.getString("maxDistortion"));
        if (Parameters.has("sensitivity"))
            this.sensitivity = Number(Parameters.getString("sensitivity"));
        if (Parameters.has("structureLayers"))
            this.structureLayers = Number(Parameters.getString("structureLayers"));
        if (Parameters.has("xyStretch"))
            this.xyStretch = Number(Parameters.getString("xyStretch"));
        if (Parameters.has("deblurPythonToolsParentFolderPath"))
            this.deblurPythonToolsParentFolderPath = Parameters.getString("deblurPythonToolsParentFolderPath");
        this.loadPathFromFile();
    },
    savePathToFile: function () {
        try {
            let file = new File;
            // console.writeln("Writing config file: " + deblurringConfigFile);
            file.createForWriting(deblurringConfigFile);
            file.outTextLn(this.deblurPythonToolsParentFolderPath);
            file.outTextLn(String(this.strideSize));
            file.outTextLn(String(this.maxDistortion));
            file.outTextLn(String(this.sensitivity));
            file.outTextLn(String(this.structureLayers));
            file.outTextLn(String(this.xyStretch));
            file.close();
        } catch (error) {
            console.warningln("Failed to save deblurPythonTools parent folder path: " + error.message);
        }
    },

    loadPathFromFile: function () {
        try {
            if (File.exists(deblurringConfigFile)) {
                let file = new File;
                // console.writeln("Reading config file: " + deblurringConfigFile);
                file.openForReading(deblurringConfigFile);
                let lines = File.readLines(deblurringConfigFile);
                if (lines.length > 0) {
                    this.deblurPythonToolsParentFolderPath = lines[0].trim();
                    this.strideSize = lines[1].trim();
                    this.maxDistortion = Number(lines[2].trim());
                    this.sensitivity = Number(lines[3].trim());
                    this.structureLayers = Number(lines[4].trim());
                    this.xyStretch = Number(lines[5].trim());
                }
                file.close();
            }
        } catch (error) {
            console.warningln("Failed to load deblurPythonTools parent folder path: " + error.message);
        }
    }
};

function SpacedVerticalSizer() {
    this.__base__ = VerticalSizer;
    this.__base__();
    this.scaledSpacing = 5;
    this.scaledMargin = 5;
}

SpacedVerticalSizer.addItem = function (item, stretchFactor = 0) {
    //console.warningln("Adding " + item.constructor.name + " to " + this.constructor.name);
    if (item.constructor.name == "Sizer" && this.parentControl != null && this.parentControl.constructor.name != "Dialog") {
        item.clearMargin([]);
    }
    this.items.push(item);
    if (stretchFactor > 0) {
        this.add(item, stretchFactor);
    } else {
        this.add(item);
    }
}


// Dialog setup, image selection, etc.
function DeblurringDialog() {
    this.__base__ = Dialog;
    this.__base__();

    console.hide();
    deblurringParameters.load();

    this.title = new Label(this);
    this.title.text = "LinearDeblur " + VERSION;
    this.title.textAlignment = TextAlign_Center;

    this.description = new TextBox(this);
   this.description.readOnly = true;
   this.description.height = 50;
   this.description.maxHeight = 50;
    this.description.text = "This script implements different deblurring " +
        "algorithms to deal with elongated stars.\n" +
        "";
    this.description.setMinWidth(800);
    // this.description.setMinHeight(150);

    this.imageSelectionLabel = new Label(this);
    this.imageSelectionLabel.text = "Select Image:";
    this.imageSelectionLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    this.imageSelectionDropdown = new ComboBox(this);
    this.imageSelectionDropdown.editEnabled = false;

    this.imageSelectionDropdown.onItemSelected = (index) => {
        if (index >= 0) {
            let window = ImageWindow.windowById(this.imageSelectionDropdown.itemText(index));
            if (window && !window.isNull) {
                deblurringParameters.targetWindow = window;
                /*
                let selectedImage = window.mainView.image;
                if (selectedImage) {
                    console.writeln("Displaying the selected image in the preview.");
                    var tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                    this.previewControl.displayImage = tmpImage;
                    this.previewControl.initScrollBars();
                    this.previewControl.viewport.update();
                    // Set the previous zoom level to the initial downsampling factor
                    this.previousZoomLevel = this.downsamplingFactor;
                } else {
                    console.error("Selected image is undefined.");
                }
                */
            } else {
                console.writeln("No valid window selected for preview!");
                // this.previewControl.visible = false;
                // this.zoomSizer.visible = false;
                this.adjustToContents();
            }
        }
    };



    let windows = ImageWindow.windows;
    let activeWindowId = ImageWindow.activeWindow.mainView.id;
    for (let i = 0; i < windows.length; ++i) {
        this.imageSelectionDropdown.addItem(windows[i].mainView.id);
        if (windows[i].mainView.id === activeWindowId) {
            this.imageSelectionDropdown.currentItem = i;
            deblurringParameters.targetWindow = windows[i];
        }
    }

    this.imageSelectionSizer = new HorizontalSizer;
    this.imageSelectionSizer.spacing = 4;
    this.imageSelectionSizer.add(this.imageSelectionLabel);
    this.imageSelectionSizer.add(this.imageSelectionDropdown, 100);

    var dlg = this;
   // this.view = view;

   this.rotateAndDeblurTab = new Control(this);

   this.rotateAndDeblurDescription = new TextBox(this);
   this.rotateAndDeblurDescription.readOnly = true;
   this.rotateAndDeblurDescription.text = "This tab applies a PSF to stars detected\n" +
      "with Pixinsight's Star Detector in the center of the\n" +
      "image. The median rotation angle is calculated and\n" +
      "the full image is rotated so that the elongated stars\n" +
      "are parallel with the horizontal plane. A machine\n" +
      "learning algorithm is applied to the horizontal blurring\n" +
      "to restore the stars to roundness. The image is then\n" +
      "rotated back and cropped to match the original orientation.\n\n" +
      "For this algorithm, the background is also deblurred.";
   // this.rotateAndDeblurDescription.setMinWidth(400);
   // this.rotateAndDeblurDescription.setMinHeight(150);

   this.rotateAndDeblurButtonTab = new PushButton(this);
   this.rotateAndDeblurButtonTab.text = "Rotate and Deblur with Background";
   this.rotateAndDeblurButtonTab.onClick = function () {
      var parent = this.parent;
      var grandparent = parent.parent;
       var greatgrandparent = grandparent.parent;
       var stars_only = false;
       let returnedStars = rotateAndDeblur(deblurringParameters.targetWindow.mainView, greatgrandparent, stars_only);

      Console.writeln('Number of stars returned by detector: ' + returnedStars.length);
   };

   this.rotateAndDeblurButtonSizerTab = new HorizontalSizer;
   this.rotateAndDeblurButtonSizerTab.spacing = 4;
   this.rotateAndDeblurButtonSizerTab.add(this.rotateAndDeblurButtonTab);

   with (this.rotateAndDeblurTab) {
      sizer = new VerticalSizer(this.rotateAndDeblurTab);
      // RADsizer = new HorizontalSizer;
      sizer.add(this.rotateAndDeblurDescription);
      sizer.spacing = 6;
      sizer.add(this.rotateAndDeblurButtonSizerTab);
      sizer.spacing = 6;
      sizer.addStretch();
   }

   this.rotateAndDeblurStarsTab = new Control(this);

   this.rotateAndDeblurStarsDescription = new TextBox(this);
   this.rotateAndDeblurStarsDescription.readOnly = true;
   this.rotateAndDeblurStarsDescription.text = "This tab applies a PSF to stars detected\n" +
      "with Pixinsight's Star Detector in the center of the\n" +
      "image. The median rotation angle is calculated and\n" +
      "the full image is rotated so that the elongated stars\n" +
      "are parallel with the horizontal plane. A machine\n" +
      "learning algorithm is applied to the horizontal blurring\n" +
      "to restore the stars to roundness. The image is then\n" +
      "rotated back and cropped to match the original orientation.\n\n" +
      "For this algorithm, the background is not deblurred,\n" +
      "only the stars.";
   // this.rotateAndDeblurStarsDescription.setMinWidth(400);
   // this.rotateAndDeblurStarsDescription.setMinHeight(150);

   this.rotateAndDeblurStarsButtonTab = new PushButton(this);
   this.rotateAndDeblurStarsButtonTab.text = "Rotate and Deblur Stars Only";
   this.rotateAndDeblurStarsButtonTab.onClick = function () {
      var parent = this.parent;
      var grandparent = parent.parent;
       var greatgrandparent = grandparent.parent;
       var stars_only = true;
       let returnedStars = rotateAndDeblur(deblurringParameters.targetWindow.mainView, greatgrandparent, stars_only);

      Console.writeln('Number of stars returned by detector: ' + returnedStars.length);
   };

   this.rotateAndDeblurButtonStarsSizerTab = new HorizontalSizer;
   this.rotateAndDeblurButtonStarsSizerTab.spacing = 4;
   this.rotateAndDeblurButtonStarsSizerTab.add(this.rotateAndDeblurStarsButtonTab);

   with (this.rotateAndDeblurStarsTab) {
      sizer = new VerticalSizer(this.rotateAndDeblurStarsTab);
      // RADsizer = new HorizontalSizer;
      sizer.add(this.rotateAndDeblurStarsDescription);
      sizer.spacing = 6;
      sizer.add(this.rotateAndDeblurButtonStarsSizerTab);
      sizer.spacing = 6;
      sizer.addStretch();
   }

   this.syntheticStarsTab = new Control(this);

   this.syntheticStarsDescription = new TextBox(this);
   this.syntheticStarsDescription.readOnly = true;
   this.syntheticStarsDescription.text = "This tab applies a PSF to stars detected\n" +
      "with Pixinsight's Star Detector. It then creates\n" +
      "a new synthetic star field with rounded stars where\n" +
      "the long axis is forced to be equal to the short axis.\n\n" +
      "The stars can then be removed from the original image\n" +
      "using a process like StarNet2, and replaced by the\n" +
      "synthetic star field.";
   // this.syntheticStarsDescription.setMinWidth(400);
   // this.syntheticStarsDescription.setMinHeight(150);

   this.syntheticStarsButtonTab = new PushButton(this);
   this.syntheticStarsButtonTab.text = "Create Synthetic Replacement Stars";
   this.syntheticStarsButtonTab.onClick = function () {
      var parent = this.parent;
      var grandparent = parent.parent;
      var greatgrandparent = grandparent.parent;
       let returnedStars = createSyntheticStars(deblurringParameters.targetWindow.mainView, greatgrandparent);
       deblurringParameters.save();

      Console.writeln('Number of stars returned by detector: ' + returnedStars.length);
   };

   this.syntheticStarsButtonSizerTab = new HorizontalSizer;
   this.syntheticStarsButtonSizerTab.spacing = 4;
    this.syntheticStarsButtonSizerTab.add(this.syntheticStarsButtonTab);
    /*
    std.sensitivity = Math.pow(10.0, -5.0);
    std.xyStretch = 1.5;
    std.maxDistortion = 0.1;
    std.minStructSize = 0;
    */


    this.SSsensitivity = new NumericControl(this);
    this.SSsensitivity.label.text = "Sensitivity power:";
    this.SSsensitivity.setRange(1, 5);
    this.SSsensitivity.setPrecision(0);
    this.SSsensitivity.setValue(deblurringParameters.sensitivity);
    this.SSsensitivity.onValueUpdated = (value) => {
        deblurringParameters.sensitivity = value;
    };

    this.SSsensitivitySizer = new HorizontalSizer;
    this.SSsensitivitySizer.spacing = 4;
    this.SSsensitivitySizer.add(this.SSsensitivity);

    this.SSstructureLayers = new NumericControl(this);
    this.SSstructureLayers.label.text = "Structure layers:";
    this.SSstructureLayers.setRange(1, 5);
    this.SSstructureLayers.setPrecision(0);
    this.SSstructureLayers.setValue(deblurringParameters.structureLayers);
    this.SSstructureLayers.onValueUpdated = (value) => {
        deblurringParameters.structureLayers = value;
    };

    this.SSstructureLayersSizer = new HorizontalSizer;
    this.SSstructureLayersSizer.spacing = 4;
    this.SSstructureLayersSizer.add(this.SSstructureLayers);


    this.SSxyStretch = new NumericControl(this);
    this.SSxyStretch.label.text = "XY stretch:";
    this.SSxyStretch.setRange(1, 3);
    this.SSxyStretch.setPrecision(1);
    this.SSxyStretch.setValue(deblurringParameters.xyStretch);
    this.SSxyStretch.onValueUpdated = (value) => {
        deblurringParameters.xyStretch = value;
    };

    this.SSxyStretchSizer = new HorizontalSizer;
    this.SSxyStretchSizer.spacing = 4;
    this.SSxyStretchSizer.add(this.SSxyStretch);



    this.SSmaxDistortion = new NumericControl(this);
    this.SSmaxDistortion.label.text = "Max distortion:";
    this.SSmaxDistortion.setRange(0, 1);
    this.SSmaxDistortion.setPrecision(2);
    // this.SSmaxDistortion.slider.setRange(0, 1);
    // this.SSmaxDistortion.setValue(0.4);
    this.SSmaxDistortion.setValue(deblurringParameters.maxDistortion);
    // this.starSizeSlider.hide(); // Hide initially
    this.SSmaxDistortion.onValueUpdated = (value) => {
        deblurringParameters.maxDistortion = value;
    };

    this.SSmaxDistortionSizer = new HorizontalSizer;
    this.SSmaxDistortionSizer.spacing = 4;
    this.SSmaxDistortionSizer.add(this.SSmaxDistortion);

   with (this.syntheticStarsTab) {
      sizer = new VerticalSizer(this.syntheticStarsTab);
      // sizer = new HorizontalSizer;
      sizer.add(this.syntheticStarsDescription);
       sizer.spacing = 6;
       sizer.add(this.SSsensitivitySizer);
       sizer.spacing = 6;
       sizer.add(this.SSstructureLayersSizer);
       sizer.spacing = 6;
       sizer.add(this.SSxyStretchSizer);
       sizer.spacing = 6;
       sizer.add(this.SSmaxDistortionSizer);
       sizer.spacing = 6;
      sizer.add(this.syntheticStarsButtonSizerTab);
      sizer.spacing = 6;
      sizer.addStretch();
   }

   this.denoiseTab = new Control(this);

   this.denoiseDescription = new TextBox(this);
   this.denoiseDescription.readOnly = true;
   this.denoiseDescription.height = 80;
   this.denoiseDescription.maxHeight = 80;
   this.denoiseDescription.text = "This tab applies a machine learning denoising\n" +
      "algorithm to the selected image. This option was\n" +
      "added because the deblurring model also seemed to\n" +
      "train well as a denoising model.";
   // this.syntheticStarsDescription.setMinWidth(400);
   // this.syntheticStarsDescription.setMinHeight(150);

   this.denoiseButtonTab = new PushButton(this);
   this.denoiseButtonTab.text = "Denoise Nonlinear";
   this.denoiseButtonTab.onClick = function () {
      var parent = this.parent;
      var grandparent = parent.parent;
      var greatgrandparent = grandparent.parent;
      let returnedDenoise = denoiseImage(deblurringParameters.targetWindow.mainView, greatgrandparent);

      Console.writeln('Image denoised');
   };

   this.denoiseButtonSizerTab = new HorizontalSizer;
   this.denoiseButtonSizerTab.spacing = 4;
   this.denoiseButtonSizerTab.add(this.denoiseButtonTab);


    this.deblurMorphTab = new Control(this);

    this.deblurMorpheDescription = new TextBox(this);
    this.deblurMorpheDescription.readOnly = true;
    this.deblurMorpheDescription.height = 120;
    this.deblurMorpheDescription.maxHeight = 120;
    this.deblurMorpheDescription.text = "This tab deblurs the stars using an analytic algorithm. It works without downloading and installing the " +
        "neural network package, although it does use StarNet2, which must be installed, and it helps significantly with the speed of the algorithm if a " +
        "GPU is available.\n\nIt works on linear and nonlinear images as well as mono, RGB/3 channel images, and drizzle images (would recommending doubling " +
        "the usual erosion amount for drizzled images).";
    // this.syntheticStarsDescription.setMinWidth(400);
    // this.syntheticStarsDescription.setMinHeight(150);

    this.linearCheckBox = new CheckBox(this);
    with (this.linearCheckBox) {
        toolTip = "Check if this is a linear image to optimize star detection"
        text = "Linear image";
        enabled = true;
        checked = deblurringParameters.linearImage;
        bindings = function () {
            this.checked = deblurringParameters.linearImage;
        }
        onCheck = function (value) {
            deblurringParameters.linearImage = value;
        }
    }

    this.erosionAmount = new NumericControl(this);
    this.erosionAmount.label.text = "Erosion amount:";
    this.erosionAmount.setRange(2, 11);
    this.erosionAmount.setPrecision(0);
    this.erosionAmount.setValue(deblurringParameters.erosionAmount);
    this.erosionAmount.onValueUpdated = (value) => {
        deblurringParameters.erosionAmount = value;
    };

    this.erosionAmountSizer = new HorizontalSizer;
    this.erosionAmountSizer.spacing = 4;
    this.erosionAmountSizer.add(this.erosionAmount);


    this.deblurMorphButtonTab = new PushButton(this);
    this.deblurMorphButtonTab.text = "Deblur Analytic";
    this.deblurMorphButtonTab.onClick = function () {
        var parent = this.parent;
        var grandparent = parent.parent;
        var greatgrandparent = grandparent.parent;
        let returnedDenoise = deblurAnalyticImage(deblurringParameters.targetWindow.mainView, greatgrandparent);

        Console.writeln('Image deblurred');
    };

    this.deblurMorphButtonSizerTab = new HorizontalSizer;
    this.deblurMorphButtonSizerTab.spacing = 4;
    this.deblurMorphButtonSizerTab.add(this.deblurMorphButtonTab);

    with (this.deblurMorphTab) {
        sizer = new VerticalSizer(this.deblurMorphTab);
        // sizer = new HorizontalSizer;
        sizer.add(this.deblurMorpheDescription);
        sizer.spacing = 6;
        sizer.add(this.linearCheckBox);
        sizer.spacing = 6;
        sizer.add(this.erosionAmountSizer);
        sizer.spacing = 6;
        sizer.add(this.deblurMorphButtonSizerTab);
        sizer.spacing = 6;
        sizer.addStretch();
    }






   this.strideLabel = new Label(this);
   this.strideLabel.text = "Stride size: ";
   this.strideLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    this.strideComboBox = new ComboBox(this);
    this.strideComboBox.toolTip = "Increase this for some speed improvement\nDecrease this if your GPU runs out of memory";
   this.strideComboBox.addItem("256");
   this.strideComboBox.addItem("384");
    this.strideComboBox.addItem("512");
    this.strideComboBox.addItem("640");
   deblurringParameters.load();
   // console.writeln("Initializing stride size from stored: " + deblurringParameters.strideSize);
   if (deblurringParameters.strideSize == 256) {
      this.strideComboBox.currentItem = 0;
   }
   else if (deblurringParameters.strideSize == 384) {
      this.strideComboBox.currentItem = 1;
   }
   else if (deblurringParameters.strideSize == 512) {
       this.strideComboBox.currentItem = 2;
   }
   else {
      this.strideComboBox.currentItem = 3;
   }

   this.strideComboBox.onItemSelected = (index) => {
      // console.writeln("Setting stride size index: " + index + " from stored: " + deblurringParameters.strideSize);
      if (index == 0) {
         deblurringParameters.strideSize = 256;
      }
      else if (index == 1) {
         deblurringParameters.strideSize = 384;
      }
      else if (index == 2) {
          deblurringParameters.strideSize = 512;
      }
      else {
         deblurringParameters.strideSize = 640;
      }

      deblurringParameters.save();
   };

   this.strideSizer = new HorizontalSizer;
   this.strideSizer.spacing = 4;
   this.strideSizer.add(this.strideLabel);
   this.strideSizer.add(this.strideComboBox);

   with (this.denoiseTab) {
      sizer = new VerticalSizer(this.denoiseTab);
      // sizer = new HorizontalSizer;
      sizer.add(this.denoiseDescription);
      
      sizer.spacing = 6;
      sizer.add(this.denoiseButtonSizerTab);
      sizer.spacing = 6;
      sizer.addStretch();
   }


   
   
   this.deblurTabBox = new TabBox(this);
   with (this.deblurTabBox) {
       addPage(this.deblurMorphTab, "Deblur Analytic");
       addPage(this.rotateAndDeblurTab, "Rotate and Deblur with Background");
      addPage(this.rotateAndDeblurStarsTab, "Rotate and Deblur Stars Only");
      addPage(this.syntheticStarsTab, "Synthetic Stars");
      addPage(this.denoiseTab, "Denoise");
      this.deblurTabBox.bindings = function () {
          this.enabled = deblurringParameters.targetView != null;
      }
   }



   /*
    this.syntheticStarsButton = new PushButton(this);
    this.syntheticStarsButton.text = "Create Synthetic Replacement Stars";
    this.syntheticStarsButton.onClick = function () {
        var parent = this.parent;
        // var grandparent = parent.parent;
        let returnedStars = createSyntheticStars(deblurringParameters.targetWindow.mainView, parent);

        Console.writeln('Number of stars returned by detector: ' + returnedStars.length);
    };

    this.syntheticStarsButtonSizer = new HorizontalSizer;
    this.syntheticStarsButtonSizer.spacing = 4;
    this.syntheticStarsButtonSizer.add(this.syntheticStarsButton);

    this.rotateAndDeblurButton = new PushButton(this);
    this.rotateAndDeblurButton.text = "Rotate and Deblur";
    this.rotateAndDeblurButton.onClick = function () {
        var parent = this.parent;
        // var grandparent = parent.parent;
        let returnedStars = rotateAndDeblur(deblurringParameters.targetWindow.mainView, parent);

        Console.writeln('Number of stars returned by detector: ' + returnedStars.length);
    };

    this.rotateAndDeblurButtonSizer = new HorizontalSizer;
    this.rotateAndDeblurButtonSizer.spacing = 4;
    this.rotateAndDeblurButtonSizer.add(this.rotateAndDeblurButton);
    */
    this.lblState = new Label(this);
    this.lblState.text = "";

    this.lblStateSizer = new HorizontalSizer;
    this.lblStateSizer.spacing = 4;
    this.lblStateSizer.add(this.lblState);

    var progressValue = 0;

    this.progressBar = new Label(this);
    with (this.progressBar) {
        lineWidth = 1;
        frameStyle = FrameStyle_Box;
        textAlignment = TextAlign_Center | TextAlign_VertCenter;

        onPaint = function (x0, y0, x1, y1) {
            var g = new Graphics(dlg.progressBar);
            g.fillRect(x0, y0, x1, y1, new Brush(0xFFFFFFFF));
            if (progressValue > 0) {
                var l = (x1 - x0 + 1) * progressValue;
                g.fillRect(x0, y0, l, y1, new Brush(0xFF00EFE0));
            }
            g.end();
            text = (progressValue * 100).toFixed(0) + "%";
        }
    }

    this.progress = function (n) {
        progressValue = n;// Math.min(n, 1);
        dlg.progressBar.repaint();
    }

    // Wrench Icon Button for setting the SetiAstroDenoise parent folder path
    this.setupButton = new ToolButton(this);
    this.setupButton.icon = this.scaledResource(":/icons/wrench.png");
    this.setupButton.setScaledFixedSize(24, 24);
    this.setupButton.onClick = function () {
        let pathDialog = new GetDirectoryDialog;
        // let pathDialog = new OpenFileDialog;
        pathDialog.initialPath = deblurringParameters.deblurPythonToolsParentFolderPath;
        if (pathDialog.execute()) {
            deblurringParameters.deblurPythonToolsParentFolderPath = pathDialog.directory;
            deblurringParameters.save();
            // this.parent.correctionFileLabel.text = deblurringParameters.deblurPythonToolsParentFolderPath;


        }
    };
    /*
    this.okButton = new PushButton(this);
    this.okButton.text = "OK";
    this.okButton.onClick = () => this.ok();

    this.cancelButton = new PushButton(this);
    this.cancelButton.text = "Cancel";
    this.cancelButton.onClick = () => this.cancel();
    */
    // New Instance button
    this.newInstanceButton = new ToolButton(this);
    this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
    this.newInstanceButton.setScaledFixedSize(24, 24);
    this.newInstanceButton.toolTip = "Save a new instance of this script";
    this.newInstanceButton.onMousePress = function () {
        this.dialog.newInstance();
    }.bind(this);

    this.undoRepairButton = new PushButton(this);
    this.undoRepairButton.text = "Undo";
    this.undoRepairButton.toolTip = "Undo the last repair";
    this.undoRepairButton.icon = ":/icons/undo.png";
    this.undoRepairButton.onClick = () => {
        if (deblurringParameters.targetWindow && !deblurringParameters.targetWindow.isNull) {
            deblurringParameters.targetWindow.undo();
        } else {
            console.writeln("No valid window selected for undo!");
        }
    };

    this.buttonsSizer = new HorizontalSizer;
    this.buttonsSizer.spacing = 6;
    this.buttonsSizer.add(this.newInstanceButton);
    this.buttonsSizer.add(this.setupButton);
    this.buttonsSizer.addStretch();
    this.buttonsSizer.add(this.undoRepairButton);
    
    // this.buttonsSizer.add(this.okButton);
    // this.buttonsSizer.add(this.cancelButton);
    this.buttonsSizer.addStretch();

    // Layout
    this.sizer = new VerticalSizer;
    this.sizer.margin = 6;
    this.sizer.spacing = 6;
    this.sizer.addStretch();
    this.sizer.add(this.title);
    this.sizer.add(this.description);
    this.sizer.addStretch();
    this.sizer.add(this.imageSelectionSizer);
   this.sizer.spacing = 6;
   this.sizer.add(this.strideSizer);
   this.sizer.spacing = 6;
   this.sizer.add(this.deblurTabBox);
   this.sizer.spacing = 6;
   /*
    this.sizer.add(this.syntheticStarsButtonSizer);
    this.sizer.spacing = 6;
    this.sizer.add(this.rotateAndDeblurButtonSizer);
    this.sizer.spacing = 6;
    */
    this.sizer.add(this.lblStateSizer);
    this.sizer.spacing = 8;
    this.sizer.add(this.progressBar);
    this.sizer.spacing = 6;
    // this.sizer.add(this.denoiseStrengthSlider);
    // this.sizer.add(this.denoiseModeSizer);
    this.sizer.addStretch();

    // GPU Acceleration checkbox (only for Windows)

    // this.gpuAccelerationCheckbox = new CheckBox(this);
    // this.gpuAccelerationCheckbox.text = "Enable GPU Acceleration";
    // this.gpuAccelerationCheckbox.checked = true;  // Default to enabled
    // this.gpuAccelerationCheckbox.onCheck = function(checked) {
    //     deblurringParameters.useGPU = checked;
    // };
    // this.sizer.add(this.gpuAccelerationCheckbox);


    // this.sizer.add(this.setupButton);
    this.sizer.addSpacing(12);
    this.sizer.add(this.buttonsSizer);

    this.windowTitle = "LinearDeblur Script";
    this.adjustToContents();


}
DeblurringDialog.prototype = new Dialog;

function saveImageAsTiff(inputFolderPath, view) {
    // Obtain the ImageWindow object from the view's main window
    let imgWindow = view.isMainView ? view.window : view.mainView.window;

    if (!imgWindow) {
        throw new Error("Image window is undefined for the specified view.");
    }

    let fileName = imgWindow.mainView.id;  // Get the main view's id as the filename
    let filePath = inputFolderPath + pathSeparator + fileName + ".xisf";

    // Set the image format to 32-bit float if not already set
    imgWindow.bitsPerSample = 32;
    imgWindow.ieeefpSampleFormat = true;

    // Save the image in XISF format
    if (!imgWindow.saveAs(filePath, false, false, false, false)) {
        throw new Error("Failed to save image as 32-bit XISF: " + filePath);
    }

    console.writeln("Image saved as 32-bit XISF: " + filePath);
    return filePath;
}



// Function to wait for the output file indefinitely
function waitForFile(outputFilePath) {
    let pollingInterval = 1000;  // Poll every 1 second
    let postFindDelay = 2000;    // Delay of 2 seconds after finding the file

    console.writeln("Waiting for output file: " + outputFilePath);
    // Keep looping until the file exists
    while (!File.exists(outputFilePath)) {
        msleep(pollingInterval);
    }

    console.writeln("Output file found: " + outputFilePath);
    console.writeln("Waiting for " + (postFindDelay / 1000) + " seconds to ensure the file is completely saved.");
    msleep(postFindDelay);

    return true;
}




// Process the denoised image after waiting for it
function processOutputImage(outputFilePath, targetView) {
   if (!File.exists(outputFilePath)) {
      console.criticalln("Denoised file not found: " + outputFilePath);
      return;
   }

   let denoisedWindow = ImageWindow.open(outputFilePath)[0];
   if (denoisedWindow) {
      denoisedWindow.show();

      // Now apply PixelMath to replace the original image with the reverted, denoised image
      let pixelMath = new PixelMath;
      pixelMath.expression = "iif(" + denoisedWindow.mainView.id + " == 0, $T, " + denoisedWindow.mainView.id + ")";
      pixelMath.useSingleExpression = true;
      pixelMath.createNewImage = false;
      pixelMath.executeOn(targetView);  // Replace the target view (main image) with the denoised one

      // Close the denoised image window after PixelMath operation
      denoisedWindow.forceClose();

      // Try deleting the temporary denoised file
      try {
         File.remove(outputFilePath);
         console.writeln("Deleted denoised file: " + outputFilePath);
      } catch (error) {
         console.warningln("Failed to delete denoised file: " + outputFilePath);
      }
   } else {
      console.criticalln("Failed to open denoised image: " + outputFilePath);
   }
}



// Function to delete the input file
function deleteInputFile(inputFilePath) {
   try {
      if (File.exists(inputFilePath)) {
         File.remove(inputFilePath);
         console.writeln("Deleted input file: " + inputFilePath);
      } else {
         console.warningln("Input file not found: " + inputFilePath);
      }
   } catch (error) {
      console.warningln("Failed to delete input file: " + inputFilePath);
   }
}


// Main execution block for running the script
let dialog = new DeblurringDialog();
console.show();
console.writeln("DeblurringDialog process started.");
console.flush();

if (dialog.execute()) {
   let selectedIndex = dialog.imageSelectionDropdown.currentItem;
   let selectedView = ImageWindow.windows[selectedIndex];

   if (!selectedView) {
      console.criticalln("Please select an image.");
   } else {
       let artifactCorrectionFileWindow = ImageWindow.open(deblurringParameters.artifactCorrectionImageFile)[0];
      if (artifactCorrectionFileWindow) {
         artifactCorrectionFileWindow.show();
      }
   }
}

function medianOfList(values) {

    if (values.length === 0) {
        throw new Error('Input array is empty');
    }

    // Sorting values, preventing original array
    // from being mutated.
    values = [...values].sort((a, b) => a - b);

    const half = Math.floor(values.length / 2);

    return (values.length % 2
        ? values[half]
        : (values[half - 1] + values[half]) / 2
    );

}


// Function to delete the input file
function getStarStats(localSelectedStars) {
    var thetaList = [];
    var sxList = [];
    var syList = [];

    for (var i in localSelectedStars) {
        var row = localSelectedStars[i];

        thetaList.push(row.theta);
        sxList.push(row.sx);
        syList.push(row.sy);
    }

    var medianTheta = medianOfList(thetaList);
    var medianSX = medianOfList(sxList);
    var medianSY = medianOfList(syList);

    Console.writeln("Median theta: " + medianTheta + " sx: " + medianSX + " sy: " + medianSY);

    return [medianTheta, medianSX, medianSY];
}


// Function to return a list of stars in an image
function getStars(workingImageView, dlg) {
    dlg.lblState.text = 'Detecting stars';
    processEvents();
    var std = new StarDetector();
    // std.sensitivity = Math.pow(10.0, sensitivity);
    std.sensitivity = Math.pow(10.0, -5.0);
    std.xyStretch = 1.5;
    std.maxDistortion = 0.1;
    std.minStructSize = 1;
    Console.writeln('Sensitivity ' + std.sensitivity);
    Console.writeln('Upper limit ' + std.upperLimit);
    Console.writeln('structureLayers ' + std.structureLayers);
    Console.writeln('xyStretch ' + std.xyStretch);
    Console.writeln('peakResponse ' + std.peakResponse);
    Console.writeln('bkgDelta ' + std.bkgDelta);
    Console.writeln('maxDistortion ' + std.maxDistortion);

    var stars = std.stars(workingImageView.image);

    Console.writeln('Number of stars detected by detector: ' + stars.length);

    Console.show();

    if (stars == null) return [];
    if (stars.length == 0) return [];

    var barycenters = new Array;
    var maxStars = 10;
    if (maxStars > stars.length) maxStars = stars.length;

    for (var i = 0; i != maxStars; ++i) {
        var s = stars[i];

        Console.writeln('First stars x: ' + s.pos.x + ' y: ' + s.pos.y);
    }
    
    // return;

    var keys = Object.keys(s);

    for (var k in keys) Console.writeln('Property ' + keys[k]);
    let minStructSize = 0;
    for (var i = 0; i != stars.length; ++i) {
        let newRadius = Math.max(3, Math.ceil(Math.sqrt(stars[i].size)));
        barycenters.push({
            position: stars[i].pos,
            radius: Math.max(3, Math.ceil(Math.sqrt(stars[i].size)))
        });
        if (newRadius > minStructSize) minStructSize = newRadius;
        // processEvents();
        // if (dlg.cancel) break;
    }

    dlg.lblState.text = 'Found ' + barycenters.length.toString() + ' stars - fitting PSF';
    processEvents();

    Console.writeln('Number of stars detected ' + barycenters.length);
    Console.flush();

    
    // P.stars = [ // viewIndex, channel, status, x0, y0, x1, y1, x, y

    var dynamicPSF = new DynamicPSF;
    var radius = Math.round(0.75 * dynamicPSF.searchRadius);

    Console.writeln('dynamicPSF radius: ' + dynamicPSF.searchRadius);
    Console.flush();

    // return;

    stars = [];

    for (var i = 0; i != barycenters.length; ++i) {
        stars.push(new Array(
            0, 0, DynamicPSF.prototype.Star_DetectedOk,
            barycenters[i].position.x - barycenters[i].radius,
            barycenters[i].position.y - barycenters[i].radius,
            barycenters[i].position.x + barycenters[i].radius,
            barycenters[i].position.y + barycenters[i].radius,
            barycenters[i].position.x,
            barycenters[i].position.y
        ));
    }
    Console.writeln("Detected stars barycenters " + barycenters.length);
    Console.writeln("Detected stars stars " + stars.length);
    Console.flush();

    // let S = std.stars(view.image);

    Console.writeln("Detected stars stars " + stars.length);

    let autoPSF = true;

    Console.writeln("Restructured stars: " + stars.length);

    Console.writeln("minStructSize pre dynamicPSF: " + minStructSize);
    Console.flush();


    let P = new DynamicPSF;
    P.views = [[workingImageView.id]];
    P.stars = stars;
    P.astrometry = false;
    P.autoAperture = true;
    P.searchRadius = minStructSize;
    P.circularPSF = false;
    P.autoPSF = autoPSF;
    P.gaussianPSF = true;
    P.moffatPSF = P.moffat10PSF = P.moffat8PSF =
        P.moffat6PSF = P.moffat4PSF = P.moffat25PSF =
        P.moffat15PSF = P.lorentzianPSF = autoPSF;
    P.variableShapePSF = false;
    if (!P.executeGlobal())
        throw "Unable to execute DynamicPSF process.";

    Console.flush();
    Console.writeln('Post dynamicPSF: ');
    Console.flush();





    stars = [];

    for (let psf = P.psf, i = 0; i < psf.length; ++i) {
        let p = psf[i];
        if (p[3] == DynamicPSF.prototype.PSF_FittedOk) {
            let x = p[6];
            let y = p[7];
            let rx = p[8] / 2;
            let ry = p[9] / 2;
            stars.push({
                x: x, y: y,
                rect: {
                    x0: x - rx, y0: y - ry,
                    x1: x + rx, y1: y + ry
                }
            });
        }
    }

    Console.writeln('Number of stars post DynamicPSF: ' + stars.length);

    stars = [];
    for (let psf = P.psf, i = 0; i < psf.length; ++i) {
        let p = psf[i];
        if (p[3] == DynamicPSF.prototype.PSF_FittedOk) {
            let x = p[6];
            let y = p[7];
            let rx = p[8] / 2;
            let ry = p[9] / 2;
            let sx = p[PSF_sx];
            let sy = p[PSF_sy];
            let aProp = p[PSF_A];
            let bProp = p[PSF_B];
            let theta = p[PSF_theta];
            let beta = p[PSF_beta];
            let mad = p[PSF_mad];
            stars.push({
                cx: x, cy: y, sx: sx, sy: sy, a: aProp, b: bProp, theta: theta, beta: beta, mad: mad,
                rect: {
                    x0: x - rx, y0: y - ry,
                    x1: x + rx, y1: y + ry
                }
            });
        }
    }

    var a = stars;

    return a;
}

function boxSize(b, a, beta, sx, sy, theta) {
   var max = moffat(0, 0, b, a, 0, 0, beta, sx, sy);

   // Console.writeln('boxSize max moffat: ' + max);

   var x = 0;
   var y = 0;
   var v = 2;

   while (true) {
      var t = new transformXY(x, 0, theta);
      var mx = moffat(x, 0, b, a, 0, 0, beta, sx, sy);
      mx /= max;
      // Console.writeln('boxSize mx moffat: ' + mx);

      if ((v - mx < 0.001) && (mx < 0.99)) break;

      v = mx;

      x += 1;

      if (x > 32) break;
   }

   // Console.writeln('boxSize x: ' + x);

   v = 2;

   while (true) {
      var t = new transformXY(x, y, theta);
      var my = moffat(0, y, b, a, 0, 0, beta, sx, sy);
      my /= max;
      // Console.writeln('boxSize mx moffat: ' + my);

      if ((v - my < 0.001) && (my < 0.99)) break;

      v = my;

      y += 1;

      if (y > 32) break;
   }

   // Console.writeln('boxSize y: ' + y);

   var box = Math.max(x - 1, y - 1);

   box *= 2;

   box += 1;

   return box;
}

function transformXY(x, y, theta) {
   this.x = x * Math.cos(theta * Math.RAD) + y * Math.sin(theta * Math.RAD);
   this.y = -x * Math.sin(theta * Math.RAD) + y * Math.cos(theta * Math.RAD);
}

function moffat(x, y, B, A, cx, cy, beta, sigmax, sigmay) {
   var sqx = sigmax * sigmax;
   var sqy = sigmay * sigmay;
   var dx2 = Math.pow(x - cx, 2);
   var dy2 = Math.pow(y - cy, 2);

   return B + A / Math.pow((1 + dx2 / sqx + dy2 / sqy), beta);
}

function createStarImage(b, a, sx, sy, theta, beta) {
   //
   // implements Moffat function
   //
   var box = boxSize(b, a, beta, sx, sy, theta);

   var c = Math.floor(box / 2);

   var cx = c + 1;
   var cy = c + 1;

   var img = new Image(box, box);

   var max = moffat(cx, cy, b, a, cx, cy, beta, sx, sy);
   var min = moffat(0, 0, b, a, cx, cy, beta, sx, sy);

   var f = 1 / (max - min);

   for (var y = 0; y < img.height; y++) {
      for (var x = 0; x < img.width; x++) {
         var t = new transformXY(- c + x, - c + y, theta);
         var m = moffat(t.x + cx, t.y + cy, b, a, cx, cy, beta, sx, sy);
         m = (m - min) * f;
         img.setSample(m, x, img.height - y - 1);
      }
   }

   return img;
}

function extractChannels(view) {
    var P = new ChannelExtraction;
    P.colorSpace = ChannelExtraction.prototype.RGB;
    P.channels = [ // enabled, id
        [true, view.id + "_temp_R"],
        [true, view.id + "_temp_G"],
        [true, view.id + "_temp_B"]
    ];
    P.sampleFormat = ChannelExtraction.prototype.SameAsSource;
    //P.inheritAstrometricSolution =

    P.executeOn(view);
}

function combine(viewR, viewG, viewB, resultView) {
    var P = new ChannelCombination;
    P.colorSpace = ChannelCombination.prototype.RGB;
    P.channels = [ // enabled, id
        [true, viewR.id],
        [true, viewG.id],
        [true, viewB.id]
    ];
    P.executeOn(resultView);
}


function createSyntheticStars(view, dlg) {
    var stars = getStars(view, dlg);

    Console.writeln('Number of stars detected by detector function: ' + stars.length);

    var starStats = getStarStats(stars);

    let medianTheta = starStats[0];
    let medianSX = starStats[1];
    let medianSY = starStats[2];

    Console.writeln("Median theta: " + medianTheta + " sx: " + medianSX + " sy: " + medianSY);

    dlg.lblState.text = 'Found ' + stars.length.toString() + ' stars - PSF fitted, now creating synthetic stars';
    processEvents();

    
    let newStarsWindow = new ImageWindow(view.image.width, view.image.height,
        view.image.numberOfChannels, // 1 channel for grayscale
        view.image.bitsPerSample,
        view.image.isReal,
        view.image.isColor
    );
    
    // let newStarsWindow = new ImageWindow(view.window);

    Console.writeln("New stars window has been setup channels: " + newStarsWindow.numberOfChannels + " bitsPerSample: " + newStarsWindow.bitsPerSample + " isReal: " + newStarsWindow.isReal);

    let newStarsImageView = newStarsWindow.mainView;
    newStarsImageView.beginProcess(UndoFlag_NoSwapFile);
    let newStarsImage = newStarsImageView.image;
    newStarsImage.fill(0); // Initialize the inverted mask image

    newStarsWindow.show();

    // return;

    let viewList = [];
    // Check if the image is a mono image
    if (view.image.numberOfChannels > 44) {
        // (new MessageBox("Only for mono images.", TITLE, StdIcon_Error, StdButton_Ok)).execute();
        // selectedImage = selectedImage[0];
        // console.noteln("Using red channel");
        extractChannels(newStarsImageView);
        viewList.push(newStarsImageView.id + "_temp_R");
        viewList.push(newStarsImageView.id + "_temp_G");
        viewList.push(newStarsImageView.id + "_temp_B");
    }

    Console.writeln("viewList length: " + viewList.length);

    // return;
    
    var P = new PixelMath;
    P.expression = "combine(starImage, starlessImage, op_screen())";
    P.expression1 = "";
    P.expression2 = "";
    P.expression3 = "";
    P.useSingleExpression = true;
    P.symbols = "";
    P.clearImageCacheAndExit = false;
    P.cacheGeneratedImages = false;
    P.generateOutput = true;
    P.singleThreaded = false;
    P.optimization = true;
    P.use64BitWorkingImage = false;
    P.rescale = false;
    P.rescaleLower = 0;
    P.rescaleUpper = 1;
    P.truncate = true;
    P.truncateLower = 0;
    P.truncateUpper = 1;
    P.createNewImage = false;
    P.showNewImage = true;
    P.newImageId = "";
    P.newImageWidth = 0;
    P.newImageHeight = 0;
    P.newImageAlpha = false;
    P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
    P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
    

    var progress = 0;

    dlg.progress(progress);

    Console.show();

    for (var i = 0; i != 10; ++i) {
        var s = stars[i];

        // Console.writeln('Still first stars x: ' + s.cx + ' y: ' + s.cy);
    }

    var channelNeighborhoodSearchSize = 2;

    for (var i = 0; i < stars.length; ++i) {
        // for (var i = 0; i < 10; ++i) {
        // singleStarImage.fill(0);

        var currentStarProfile = stars[i];

        var newStarImage = createStarImage(currentStarProfile.b, currentStarProfile.a, currentStarProfile.sy, currentStarProfile.sy, currentStarProfile.theta, currentStarProfile.beta);

        // if (i < 10) Console.writeln("New star: " + i + " created width: " + newStarImage.width + " height: " + newStarImage.height);

        let starCenterX = currentStarProfile.cx;
        let starCenterY = currentStarProfile.cy;

        // Console.writeln("starCenterX: " + starCenterX + " starCenterY: " + starCenterY);
        // console.flush();

        if ((starCenterX < newStarsImage.width) && (starCenterY < newStarsImage.height) && (starCenterX >= 0) && (starCenterY >= 0)) {
            let offsetX = starCenterX - (newStarImage.width / 2);
            let offsetY = starCenterY - (newStarImage.height / 2);

            if (view.image.numberOfChannels > 1) {
                for (let channelNumber = 0; channelNumber < view.image.numberOfChannels; channelNumber++) {
                    let localPeakValue = 0;

                    // Check neighborhood
                    
                    for (let i = starCenterY - channelNeighborhoodSearchSize; i <= starCenterY + channelNeighborhoodSearchSize; i++) {
                        for (let j = starCenterX - channelNeighborhoodSearchSize; j <= starCenterX + channelNeighborhoodSearchSize; j++) {
                            if ((j < view.image.width) && (i < view.image.height)) {
                                if (view.image.sample(starCenterX, starCenterY, channelNumber) > localPeakValue) {
                                    localPeakValue = view.image.sample(starCenterX, starCenterY, channelNumber);
                                }
                            }
                        }
                    }
                    
                    var originalPeakValue = localPeakValue;
                    
                    var maxNewStarPeak = 0;

                    // let selectedImageChannelView = View.viewById(viewList[channelNumber]);
                    // let selectedImageChannel = selectedImageChannelView.image;

                    for (let x = 0; x < newStarImage.width; x++) {
                        for (let y = 0; y < newStarImage.height; y++) {
                            var scaledNewValue = newStarImage.sample(x, y) * originalPeakValue;
                            // var scaledNewValue = originalPeakValue;
                            // Console.writeln("x: " + x + " offsetX: " + offsetX + "y: " + y + " offsetY: " + offsetY + " width: " + newStarImage.width + " height: " + newStarImage.height);
                            if ((x + offsetX < newStarsImage.width) && (y + offsetY < newStarsImage.height) && (x + offsetX > 0) && (y + offsetY > 0))
                                if (newStarsImage.sample(x + offsetX, y + offsetY, channelNumber) < scaledNewValue) newStarsImage.setSample(scaledNewValue, x + offsetX, y + offsetY, channelNumber);
                            // singleStarImage.setSample(newStarImage.sample(x, y) * originalPeakValue, x + offsetX, y + offsetY);
                            // if (newStarImage.sample(x, y) > maxNewStarPeak) maxNewStarPeak = newStarImage.sample(x, y);
                        }
                    }
                }
            }
            else {
                var originalPeakValue = view.image.sample(starCenterX, starCenterY);
                // Console.writeln("originalPeakValue: " + originalPeakValue);
                var maxNewStarPeak = 0;

                for (let x = 0; x < newStarImage.width; x++) {
                    for (let y = 0; y < newStarImage.height; y++) {
                        var scaledNewValue = newStarImage.sample(x, y) * originalPeakValue;
                        // Console.writeln("x: " + x + " offsetX: " + offsetX + "y: " + y + " offsetY: " + offsetY + " width: " + newStarImage.width + " height: " + newStarImage.height);
                        if ((x + offsetX < newStarsImage.width) && (y + offsetY < newStarsImage.height) && (x + offsetX > 0) && (y + offsetY > 0))
                            if (newStarsImage.sample(x + offsetX, y + offsetY) < scaledNewValue) newStarsImage.setSample(scaledNewValue, x + offsetX, y + offsetY);
                        // singleStarImage.setSample(newStarImage.sample(x, y) * originalPeakValue, x + offsetX, y + offsetY);
                        // if (newStarImage.sample(x, y) > maxNewStarPeak) maxNewStarPeak = newStarImage.sample(x, y);
                    }
                }
            }
        }
        

        

        progress = i / stars.length;
        
        dlg.progress(progress);
    }

    dlg.lblState.text = 'Found ' + stars.length.toString() + ' stars - synthetic stars created';
    processEvents();

    // singleStarWindow.show();

    if (view.image.numberOfChannels > 44) {
        // (new MessageBox("Only for mono images.", TITLE, StdIcon_Error, StdButton_Ok)).execute();
        // selectedImage = selectedImage[0];
        // console.noteln("Using red channel");
        let viewR = View.viewById(newStarsImageView.id + "_temp_R");
        let viewG = View.viewById(newStarsImageView.id + "_temp_G");
        let viewB = View.viewById(newStarsImageView.id + "_temp_B");
        combine(viewR, viewG, viewB, newStarsImageView);
        // this.createAndDisplayTemporaryImage(parameters.targetWindow.mainView.image);
        // this.previewControl.shapes = [];
        viewR.window.forceClose();
        viewG.window.forceClose();
        viewB.window.forceClose();
    }

    newStarsWindow.show();

    return stars;
}


// Create batch file to run the denoise process
function createBatchFile(batchFilePath, exePath, useGPU, inputFilePath, stars_only, useDenoiseWeights=false) {
    let batchContent;

    if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
        console.writeln("Deblurring : " + inputFilePath);
        batchContent = "@echo off\n";
        batchContent += "cd /d \"" + exePath + "\"\n";
        if (stars_only) {
            batchContent += "start DeEggify.exe --test_model weights/Best_stars_only.pkl ";
        }
        else if (useDenoiseWeights) {
            batchContent += "start DeEggify.exe --test_model weights/Best_denoising2.pkl ";
        }
        else {
          batchContent += "start DeEggify.exe --test_model weights/Best_plus_background.pkl ";
        }
        batchContent += "--stride_size " + deblurringParameters.strideSize;
        batchContent += " --filename \"" + inputFilePath + "\"\n";
    } else {
        console.criticalln("Unsupported platform: " + CoreApplication.platform);
        return false;
    }

    // Write the script to the specified path
    try {
        File.writeTextFile(batchFilePath, batchContent);
        console.writeln((CoreApplication.platform == "Linux") ?
            "Shell script created: " + batchFilePath :
            "Batch file created: " + batchFilePath);
    } catch (error) {
        console.criticalln("Failed to create batch/shell file: " + error.message);
        return false;
    }

    console.writeln("Finished creating batch file.");

    return true;
}





function rotateAndDeblur(view, dlg, stars_only) {
    var originalImageWidth = view.image.width;
    var originalImageHeight = view.image.height;

    let cropImageWindow = new ImageWindow(view.image.width, view.image.height,
        view.image.numberOfChannels, // 1 channel for grayscale
        view.image.bitsPerSample,
        view.image.isReal,
        view.image.isColor
    );

    Console.writeln("New stars window has been setup");

    let cropImageView = cropImageWindow.mainView;
    cropImageView.beginProcess(UndoFlag_NoSwapFile);
    let cropImage = cropImageView.image;
    cropImage.apply(view.image); // Initialize the inverted mask image

    const midImageCropSize = 1024;

    // image width
    // var cropWidth = -1 * Math.floor((view.image.width - midImageCropSize) / 2);
    // var cropHeight = -1 * Math.floor((view.image.height - midImageCropSize) / 2);

    var cropPercentage = 0.25;

    var cropWidth = -1 * Math.floor(view.image.width * cropPercentage);
    var cropHeight = -1 * Math.floor(view.image.height * cropPercentage);

    var P = new Crop;
    P.leftMargin = cropWidth;
    P.topMargin = cropHeight;
    P.rightMargin = cropWidth;
    P.bottomMargin = cropHeight;
    P.mode = Crop.prototype.AbsolutePixels;
    P.xResolution = 72.000;
    P.yResolution = 72.000;
    P.metric = false;
    P.forceResolution = false;
    P.red = 0.000000;
    P.green = 0.000000;
    P.blue = 0.000000;
    P.alpha = 1.000000;
    P.noGUIMessages = false;

    P.executeOn(cropImageView);

    cropImageWindow.show();

    var stars = getStars(cropImageView, dlg);

    Console.writeln('Number of stars detected by detector function: ' + stars.length);

    var starStats = getStarStats(stars);

    let medianTheta = starStats[0];
    let medianSX = starStats[1];
    let medianSY = starStats[2];

    Console.writeln("Median theta: " + medianTheta + " sx: " + medianSX + " sy: " + medianSY);

    var blurAmount = medianSX - medianSY;

    dlg.lblState.text = 'Found stars rotated at angle ' + medianTheta;
    processEvents();

    Console.writeln("Ready to rotate");

    var pi = Math.PI;
    // Multiply degrees by pi divided by 180 to convert to radians.
    var radiansToRotate = -1 * medianTheta * (pi / 180);

    var P = new Rotation;
    P.angle = radiansToRotate;
    P.optimizeFast = true;
    P.interpolation = Rotation.prototype.Auto;
    P.clampingThreshold = 0.30;
    P.smoothness = 1.50;
    P.gammaCorrection = false;
    P.red = 0.000000;
    P.green = 0.000000;
    P.blue = 0.000000;
    P.alpha = 1.000000;
    P.noGUIMessages = false;

    P.executeOn(view);

    Console.writeln("Rotated: " + radiansToRotate);



    let inputFolderPath = deblurringParameters.deblurPythonToolsParentFolderPath + pathSeparator + "working";
    let outputFolderPath = deblurringParameters.deblurPythonToolsParentFolderPath + pathSeparator + "working";
    // let outputFolderPath = deblurringParameters.deblurPythonToolsParentFolderPath;
    let outputFileName = view.id + "_deblurred.xisf";
    // let outputFileName = "Rotated_deblurred.fits";
    let outputFilePath = outputFolderPath + pathSeparator + outputFileName;
    console.writeln("Output file path: " + outputFilePath);

    let inputFilePath = saveImageAsTiff(inputFolderPath, view);
    console.writeln("Input file path: " + inputFilePath);
   let batchFilePath = deblurringParameters.deblurPythonToolsParentFolderPath + pathSeparator + "run_deblurPython" + SCRIPT_EXT;

   if (createBatchFile(batchFilePath, deblurringParameters.deblurPythonToolsParentFolderPath, deblurringParameters.useGPU, inputFilePath, stars_only)) {

        let process = new ExternalProcess;

        try {
            if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
                if (!process.start(CMD_EXEC, ["/c", batchFilePath])) {
                    console.writeln("deblurPython started.");
                    console.flush();
                    console.writeln("deblurPython finished inside loop.");
                }
            }
        } catch (error) {
            console.criticalln("Error starting process: " + error.message);
        }


        // process.start(CMD_EXEC, ["/c", batchFilePath]);
        console.flush();
        console.writeln("deblurPython started.");
        console.flush();
        console.writeln("deblurPython finished outside loop.");
        console.flush();

        if (waitForFile(outputFilePath)) {
            processOutputImage(outputFilePath, view);
            deleteInputFile(inputFilePath);
        } else {
            console.criticalln("Output file not found within timeout.");
        }
    }

    cropImageWindow.forceClose();

    dlg.lblState.text = 'Image deblurred at angle ' + medianTheta;
    processEvents();

    radiansToRotate = medianTheta * (pi / 180);

    var P = new Rotation;
    P.angle = radiansToRotate;
    P.optimizeFast = true;
    P.interpolation = Rotation.prototype.Auto;
    P.clampingThreshold = 0.30;
    P.smoothness = 1.50;
    P.gammaCorrection = false;
    P.red = 0.000000;
    P.green = 0.000000;
    P.blue = 0.000000;
    P.alpha = 1.000000;
    P.noGUIMessages = false;

    P.executeOn(view);

    Console.writeln("Rotated back: " + radiansToRotate);

    cropWidth = -1 * Math.floor((view.image.width - originalImageWidth) / 2);
    cropHeight = -1 * Math.floor((view.image.height - originalImageHeight) / 2);

    var cropWidthRight = -1 * (view.image.width - (originalImageWidth - cropWidth));
    var cropWidthBottom = -1 * (view.image.height - (originalImageHeight - cropHeight));

    Console.writeln("originalImageWidth: " + originalImageWidth + ' originalImageHeight: ' + originalImageHeight);
    Console.writeln("current image width: " + view.image.width + ' current image height: ' + view.image.height);
    Console.writeln("cropWidth: " + cropWidth + ' cropHeight: ' + cropHeight + "cropWidthRight: " + cropWidthRight + ' cropHeightBottom: ' + cropWidthBottom);

    var P = new Crop;
    P.leftMargin = cropWidth;
    P.topMargin = cropHeight;
    P.rightMargin = cropWidthRight;
    P.bottomMargin = cropWidthBottom;
    P.mode = Crop.prototype.AbsolutePixels;
    P.xResolution = 72.000;
    P.yResolution = 72.000;
    P.metric = false;
    P.forceResolution = false;
    P.red = 0.000000;
    P.green = 0.000000;
    P.blue = 0.000000;
    P.alpha = 1.000000;
    P.noGUIMessages = false;

    P.executeOn(view);


    return stars;
}


function deblurAnalyticImage(view, dlg) {
    var originalImageWidth = view.image.width;
    var originalImageHeight = view.image.height;

    let cropImageWindow = new ImageWindow(view.image.width, view.image.height,
        view.image.numberOfChannels, // 1 channel for grayscale
        view.image.bitsPerSample,
        view.image.isReal,
        view.image.isColor
    );

    Console.writeln("New stars window has been setup");

    let cropImageView = cropImageWindow.mainView;
    cropImageView.beginProcess(UndoFlag_NoSwapFile);
    let cropImage = cropImageView.image;
    cropImage.apply(view.image); // Initialize the inverted mask image

    const midImageCropSize = 1024;

    // image width
    // var cropWidth = -1 * Math.floor((view.image.width - midImageCropSize) / 2);
    // var cropHeight = -1 * Math.floor((view.image.height - midImageCropSize) / 2);

    var cropPercentage = 0.25;

    var cropWidth = -1 * Math.floor(view.image.width * cropPercentage);
    var cropHeight = -1 * Math.floor(view.image.height * cropPercentage);

    var P = new Crop;
    P.leftMargin = cropWidth;
    P.topMargin = cropHeight;
    P.rightMargin = cropWidth;
    P.bottomMargin = cropHeight;
    P.mode = Crop.prototype.AbsolutePixels;
    P.xResolution = 72.000;
    P.yResolution = 72.000;
    P.metric = false;
    P.forceResolution = false;
    P.red = 0.000000;
    P.green = 0.000000;
    P.blue = 0.000000;
    P.alpha = 1.000000;
    P.noGUIMessages = false;

    P.executeOn(cropImageView);

    cropImageWindow.show();

    var stars = getStars(cropImageView, dlg);

    Console.writeln('Number of stars detected by detector function: ' + stars.length);

    var starStats = getStarStats(stars);

    let medianTheta = starStats[0];
    let medianSX = starStats[1];
    let medianSY = starStats[2];

    Console.writeln("Median theta: " + medianTheta + " sx: " + medianSX + " sy: " + medianSY);

    var blurAmount = medianSX - medianSY;

    dlg.lblState.text = 'Found stars rotated at angle ' + medianTheta;
    processEvents();

    Console.writeln("Ready to rotate");

    var pi = Math.PI;
    // Multiply degrees by pi divided by 180 to convert to radians.
    var radiansToRotate = -1 * medianTheta * (pi / 180);

    var P = new Rotation;
    P.angle = radiansToRotate;
    P.optimizeFast = true;
    P.interpolation = Rotation.prototype.Auto;
    P.clampingThreshold = 0.30;
    P.smoothness = 1.50;
    P.gammaCorrection = false;
    P.red = 0.000000;
    P.green = 0.000000;
    P.blue = 0.000000;
    P.alpha = 1.000000;
    P.noGUIMessages = false;

    P.executeOn(view);

    Console.writeln("Rotated: " + radiansToRotate);

    /*
    if (view.computeOrFetchProperty("Median").at(0) < 0.1) {
        let result = dialog.showWarningDialog("Median lower 0.1. Unlikely this is a linear image. This script only works on non-linear images.", "Failed to load", "Continue anyway", true);
        if (result != 1) {
            dialog.mainViewSelector.remove(view);
            CurrentProcessingInfo.mainViewId = null;
            return;
        }
    }
    */

    dlg.lblState.text = 'Using StarNet2 to get stars';
    processEvents();



    var PSN = new StarNet2;
    PSN.stride = StarNet2.prototype.defStride;
    PSN.mask = true;
    PSN.linear = deblurringParameters.linearImage;
    PSN.upsample = false;
    PSN.shadows_clipping = -2.80;
    PSN.target_background = 0.25;

    PSN.executeOn(view);

    dlg.lblState.text = 'StarNet2 operation completed - deblurring';
    processEvents();

    var PMorph = new MorphologicalTransformation;
    PMorph.operator = MorphologicalTransformation.prototype.Erosion;
    PMorph.interlacingDistance = 1;
    PMorph.lowThreshold = 0.000000;
    PMorph.highThreshold = 0.000000;
    PMorph.numberOfIterations = 1;
    PMorph.amount = 1.00;
    PMorph.selectionPoint = 0.50;
    PMorph.structureName = "";
    

    if (deblurringParameters.erosionAmount == 2) {
        PMorph.structureSize = 3;
        PMorph.structureWayTable = [ // mask
            [[
                0x00, 0x00, 0x00,
                0x00, 0x01, 0x01,
                0x00, 0x00, 0x00
            ]]
        ];
    }
    else if (deblurringParameters.erosionAmount == 3) {
        PMorph.structureSize = 3;
        PMorph.structureWayTable = [ // mask
            [[
                0x00, 0x00, 0x00,
                0x01, 0x01, 0x01,
                0x00, 0x00, 0x00
            ]]
        ];
    }
    else if (deblurringParameters.erosionAmount == 4) {
        PMorph.structureSize = 5;
        PMorph.structureWayTable = [ // mask
            [[
                0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00,
                0x01, 0x01, 0x01, 0x01, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00
            ]]
        ];
    }
    else if (deblurringParameters.erosionAmount == 5) {
        PMorph.structureSize = 5;
        PMorph.structureWayTable = [ // mask
            [[
                0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00,
                0x01, 0x01, 0x01, 0x01, 0x01,
                0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00
            ]]
        ];
    }
    else if (deblurringParameters.erosionAmount == 6) {
        PMorph.structureSize = 7;
        PMorph.structureWayTable = [ // mask
            [[
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
            ]]
        ];
    }
    else if (deblurringParameters.erosionAmount == 7) {
        PMorph.structureSize = 7;
        PMorph.structureWayTable = [ // mask
            [[
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
            ]]
        ];
    }
    else if (deblurringParameters.erosionAmount == 8) {
        PMorph.structureSize = 9;
        PMorph.structureWayTable = [ // mask
            [[
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
            ]]
        ];
    }
    else if (deblurringParameters.erosionAmount == 9) {
        PMorph.structureSize = 9;
        PMorph.structureWayTable = [ // mask
            [[
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
            ]]
        ];
    }
    else if (deblurringParameters.erosionAmount == 10) {
        PMorph.structureSize = 11;
        PMorph.structureWayTable = [ // mask
            [[
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
            ]]
        ];
    }
    else {
        PMorph.structureSize = 11;
        PMorph.structureWayTable = [ // mask
            [[
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
            ]]
        ];
    }

    Console.writeln("Erosion matrix: " + PMorph.structureWayTable);

    let starMaskView = View.viewById('star_mask');

    PMorph.executeOn(starMaskView);

    dlg.lblState.text = 'Deblurred - combining stars and starless image';
    processEvents();

    
    var P = new PixelMath;
    P.expression = "combine(" + view.id + "," + starMaskView.id + ",op_screen())";
    P.expression1 = "";
    P.expression2 = "";
    P.expression3 = "";
    P.useSingleExpression = true;
    P.symbols = "";
    P.clearImageCacheAndExit = false;
    P.cacheGeneratedImages = false;
    P.generateOutput = true;
    P.singleThreaded = false;
    P.optimization = true;
    P.use64BitWorkingImage = false;
    P.rescale = false;
    P.rescaleLower = 0;
    P.rescaleUpper = 1;
    P.truncate = true;
    P.truncateLower = 0;
    P.truncateUpper = 1;
    P.createNewImage = false;
    P.showNewImage = true;
    P.newImageId = "";
    P.newImageWidth = 0;
    P.newImageHeight = 0;
    P.newImageAlpha = false;
    P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
    P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

    P.executeOn(view);

    dlg.lblState.text = 'Recombined - rotating back';
    processEvents();

    

    cropImageWindow.forceClose();
    starMaskView.window.forceClose();

    
    radiansToRotate = medianTheta * (pi / 180);

    var P = new Rotation;
    P.angle = radiansToRotate;
    P.optimizeFast = true;
    P.interpolation = Rotation.prototype.Auto;
    P.clampingThreshold = 0.30;
    P.smoothness = 1.50;
    P.gammaCorrection = false;
    P.red = 0.000000;
    P.green = 0.000000;
    P.blue = 0.000000;
    P.alpha = 1.000000;
    P.noGUIMessages = false;

    P.executeOn(view);

    Console.writeln("Rotated back: " + radiansToRotate);

    cropWidth = -1 * Math.floor((view.image.width - originalImageWidth) / 2);
    cropHeight = -1 * Math.floor((view.image.height - originalImageHeight) / 2);

    var cropWidthRight = -1 * (view.image.width - (originalImageWidth - cropWidth));
    var cropWidthBottom = -1 * (view.image.height - (originalImageHeight - cropHeight));

    Console.writeln("originalImageWidth: " + originalImageWidth + ' originalImageHeight: ' + originalImageHeight);
    Console.writeln("current image width: " + view.image.width + ' current image height: ' + view.image.height);
    Console.writeln("cropWidth: " + cropWidth + ' cropHeight: ' + cropHeight + "cropWidthRight: " + cropWidthRight + ' cropHeightBottom: ' + cropWidthBottom);

    var P = new Crop;
    P.leftMargin = cropWidth;
    P.topMargin = cropHeight;
    P.rightMargin = cropWidthRight;
    P.bottomMargin = cropWidthBottom;
    P.mode = Crop.prototype.AbsolutePixels;
    P.xResolution = 72.000;
    P.yResolution = 72.000;
    P.metric = false;
    P.forceResolution = false;
    P.red = 0.000000;
    P.green = 0.000000;
    P.blue = 0.000000;
    P.alpha = 1.000000;
    P.noGUIMessages = false;

    P.executeOn(view);


    return stars;
}





function denoiseImage(view, dlg) {
   let inputFolderPath = deblurringParameters.deblurPythonToolsParentFolderPath + pathSeparator + "working";
   let outputFolderPath = deblurringParameters.deblurPythonToolsParentFolderPath + pathSeparator + "working";
   // let outputFolderPath = deblurringParameters.deblurPythonToolsParentFolderPath;
   let outputFileName = view.id + "_deblurred.xisf";
   // let outputFileName = "Rotated_deblurred.fits";
   let outputFilePath = outputFolderPath + pathSeparator + outputFileName;
   console.writeln("Output file path: " + outputFilePath);

   let inputFilePath = saveImageAsTiff(inputFolderPath, view);
   console.writeln("Input file path: " + inputFilePath);
   let batchFilePath = deblurringParameters.deblurPythonToolsParentFolderPath + pathSeparator + "run_deblurPython" + SCRIPT_EXT;

   let stars_only = false;
   let useDenoiseWeights = true;

   if (createBatchFile(batchFilePath, deblurringParameters.deblurPythonToolsParentFolderPath, deblurringParameters.useGPU, inputFilePath, stars_only, useDenoiseWeights)) {

      let process = new ExternalProcess;

      try {
         if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
            if (!process.start(CMD_EXEC, ["/c", batchFilePath])) {
               console.writeln("deblurPython started.");
               console.flush();
               console.writeln("deblurPython finished inside loop.");
            }
         }
      } catch (error) {
         console.criticalln("Error starting process: " + error.message);
      }


      // process.start(CMD_EXEC, ["/c", batchFilePath]);
      console.flush();
      console.writeln("denoisePython started.");
      console.flush();
      
      if (waitForFile(outputFilePath)) {
         processOutputImage(outputFilePath, view);
         deleteInputFile(inputFilePath);
      } else {
         console.criticalln("Output file not found within timeout.");
      }
   }

   dlg.lblState.text = 'Image denoised';
   processEvents();

   
   return true;
}

